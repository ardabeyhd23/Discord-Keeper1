import app from "./app";
import { startFrArdaBot } from "./bot";
import { logger } from "./lib/logger";
import { initDatabase } from "@workspace/db";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

async function start(): Promise<void> {
  await initDatabase();
  app.listen(port, (err) => {
    if (err) {
      logger.error({ err }, "Error listening on port");
      process.exit(1);
    }

    logger.info({ port }, "Server listening");
    startFrArdaBot();
  });
}

start().catch((error) => {
  logger.error({ err: error }, "Veritabanı başlatılamadı");
  process.exit(1);
});
